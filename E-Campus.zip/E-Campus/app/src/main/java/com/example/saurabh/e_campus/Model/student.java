package com.example.saurabh.e_campus.Model;

/**
 * Created by SAURABH on 3/2/2018.
 */

public class student {
    private String Contact;
    private String Current_sem;
    private String Dob;
    private String Email;
    private String Full_name;
    private String Gender;
    private String Grad_course;
    private String University;
    private String Password;
    private String Hsc_board;
    private String Hsc_passyr;
    private String Hsc_percent;
    private String Ssc_board;
    private String Ssc_passyr;
    private String Ssc_percent;
    private String Sem1;
    private String Sem1_dop;
    private String Sem2;
    private String Sem2_dop;
    private String Sem3;
    private String Sem3_dop;
    private String Sem4;
    private String Sem4_dop;
    private String Sem5;
    private String Sem5_dop;
    private String Sem6;
    private String Sem6_dop;
    private String Sem7;
    private String Sem7_dop;
    private String Sem8;
    private String Sem8_dop;

    public student()
    {

    }

    public student(String full_name,  String dob, String email,String contact,String password)
    {
        Contact = contact;
        Password = password;
        Dob = dob;
        Email = email;
        Full_name = full_name;
    }

    public void stussc(String full_name, String gender, String dob, String email,String contact,String password, String ssc_percent,String ssc_passyr,String ssc_board)
    {
        Contact = contact;
        Password = password;
        Dob = dob;
        Email = email;
        Full_name = full_name;
        Gender = gender;
        Ssc_percent=ssc_percent;
        Ssc_passyr=ssc_passyr;
        Ssc_board=ssc_board;
    }

    public void stuhsc(String full_name, String gender, String dob, String email,String contact,String password, String ssc_percent,String ssc_passyr,String ssc_board,String hsc_percent,String hsc_passyr,String hsc_board)
    {
        Contact = contact;
        Password = password;
        Dob = dob;
        Email = email;
        Full_name = full_name;
        Gender = gender;
        Ssc_percent=ssc_percent;
        Ssc_passyr=ssc_passyr;
        Ssc_board=ssc_board;
        Hsc_board = hsc_board;
        Hsc_passyr = hsc_passyr;
        Hsc_percent = hsc_percent;
    }

    public void stugrad(String full_name, String gender, String dob, String email,String contact,String password, String ssc_percent,String ssc_passyr,String ssc_board,String hsc_percent,String hsc_passyr,String hsc_board,String grad_course,String university,String current_sem,String sem1, String sem1_dop, String sem2, String sem2_dop, String sem3, String sem3_dop, String sem4, String sem4_dop, String sem5, String sem5_dop, String sem6, String sem6_dop, String sem7, String sem7_dop, String sem8, String sem8_dop)
    {
        Contact = contact;
        Password = password;
        Dob = dob;
        Email = email;
        Full_name = full_name;
        Gender = gender;
        Ssc_percent=ssc_percent;
        Ssc_passyr=ssc_passyr;
        Ssc_board=ssc_board;
        Hsc_board = hsc_board;
        Hsc_passyr = hsc_passyr;
        Hsc_percent = hsc_percent;
        Grad_course = grad_course;
        University = university;
        Current_sem = current_sem;
        Sem1 = sem1;
        Sem1_dop = sem1_dop;
        Sem2 = sem2;
        Sem2_dop = sem2_dop;
        Sem3 = sem3;
        Sem3_dop = sem3_dop;
        Sem4 = sem4;
        Sem4_dop = sem4_dop;
        Sem5 = sem5;
        Sem5_dop = sem5_dop;
        Sem6 = sem6;
        Sem6_dop = sem6_dop;
        Sem7 = sem7;
        Sem7_dop = sem7_dop;
        Sem8 = sem8;
        Sem8_dop = sem8_dop;
    }


    /*public student( String contact,  String current_sem, String dob,String email,String full_name,String gender,String grad_course,String university, String password, String hsc_board, String hsc_passyr, String hsc_percent, String ssc_board, String ssc_passyr, String ssc_percent, String sem1, String sem1_dop, String sem2, String sem2_dop, String sem3, String sem3_dop, String sem4, String sem4_dop, String sem5, String sem5_dop, String sem6, String sem6_dop, String sem7, String sem7_dop, String sem8, String sem8_dop)
    {
        Contact = contact;
        Current_sem = current_sem;
        Dob = dob;
        Email = email;
        Full_name = full_name;
        Gender = gender;
        Grad_course = grad_course;
        University = university;
        Password = password;
        Hsc_board = hsc_board;
        Hsc_passyr = hsc_passyr;
        Hsc_percent = hsc_percent;
        Ssc_board = ssc_board;
        Ssc_passyr = ssc_passyr;
        Ssc_percent = ssc_percent;
        Sem1 = sem1;
        Sem1_dop = sem1_dop;
        Sem2 = sem2;
        Sem2_dop = sem2_dop;
        Sem3 = sem3;
        Sem3_dop = sem3_dop;
        Sem4 = sem4;
        Sem4_dop = sem4_dop;
        Sem5 = sem5;
        Sem5_dop = sem5_dop;
        Sem6 = sem6;
        Sem6_dop = sem6_dop;
        Sem7 = sem7;
        Sem7_dop = sem7_dop;
        Sem8 = sem8;
        Sem8_dop = sem8_dop;
    }*/

    public String getContact() {
        return Contact;
    }

    public void setContact(String contact) {
        Contact = contact;
    }

    public String getCurrent_sem() {
        return Current_sem;
    }

    public void setCurrent_sem(String current_sem) {
        Current_sem = current_sem;
    }

    public String getDob() {
        return Dob;
    }

    public void setDob(String dob) {
        Dob = dob;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getFull_name() {
        return Full_name;
    }

    public void setFull_name(String full_name) {
        Full_name = full_name;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getGrad_course() {
        return Grad_course;
    }

    public void setGrad_course(String grad_course) {
        Grad_course = grad_course;
    }

    public String getUniversity() {
        return University;
    }

    public void setUniversity(String university) {
        University = university;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getHsc_board() {
        return Hsc_board;
    }

    public void setHsc_board(String hsc_board) {
        Hsc_board = hsc_board;
    }

    public String getHsc_passyr() {
        return Hsc_passyr;
    }

    public void setHsc_passyr(String hsc_passyr) {
        Hsc_passyr = hsc_passyr;
    }

    public String getHsc_percent() {
        return Hsc_percent;
    }

    public void setHsc_percent(String hsc_percent) {
        Hsc_percent = hsc_percent;
    }

    public String getSsc_board() {
        return Ssc_board;
    }

    public void setSsc_board(String ssc_board) {
        Ssc_board = ssc_board;
    }

    public String getSsc_passyr() {
        return Ssc_passyr;
    }

    public void setSsc_passyr(String ssc_passyr) {
        Ssc_passyr = ssc_passyr;
    }

    public String getSsc_percent() {
        return Ssc_percent;
    }

    public void setSsc_percent(String ssc_percent) {
        Ssc_percent = ssc_percent;
    }

    public String getSem1() {
        return Sem1;
    }

    public void setSem1(String sem1) {
        Sem1 = sem1;
    }

    public String getSem1_dop() {
        return Sem1_dop;
    }

    public void setSem1_dop(String sem1_dop) {
        Sem1_dop = sem1_dop;
    }

    public String getSem2() {
        return Sem2;
    }

    public void setSem2(String sem2) {
        Sem2 = sem2;
    }

    public String getSem2_dop() {
        return Sem2_dop;
    }

    public void setSem2_dop(String sem2_dop) {
        Sem2_dop = sem2_dop;
    }

    public String getSem3() {
        return Sem3;
    }

    public void setSem3(String sem3) {
        Sem3 = sem3;
    }

    public String getSem3_dop() {
        return Sem3_dop;
    }

    public void setSem3_dop(String sem3_dop) {
        Sem3_dop = sem3_dop;
    }

    public String getSem4() {
        return Sem4;
    }

    public void setSem4(String sem4) {
        Sem4 = sem4;
    }

    public String getSem4_dop() {
        return Sem4_dop;
    }

    public void setSem4_dop(String sem4_dop) {
        Sem4_dop = sem4_dop;
    }

    public String getSem5() {
        return Sem5;
    }

    public void setSem5(String sem5) {
        Sem5 = sem5;
    }

    public String getSem5_dop() {
        return Sem5_dop;
    }

    public void setSem5_dop(String sem5_dop) {
        Sem5_dop = sem5_dop;
    }

    public String getSem6() {
        return Sem6;
    }

    public void setSem6(String sem6) {
        Sem6 = sem6;
    }

    public String getSem6_dop() {
        return Sem6_dop;
    }

    public void setSem6_dop(String sem6_dop) {
        Sem6_dop = sem6_dop;
    }

    public String getSem7() {
        return Sem7;
    }

    public void setSem7(String sem7) {
        Sem7 = sem7;
    }

    public String getSem7_dop() {
        return Sem7_dop;
    }

    public void setSem7_dop(String sem7_dop) {
        Sem7_dop = sem7_dop;
    }

    public String getSem8() {
        return Sem8;
    }

    public void setSem8(String sem8) {
        Sem8 = sem8;
    }

    public String getSem8_dop() {
        return Sem8_dop;
    }

    public void setSem8_dop(String sem8_dop) {
        Sem8_dop = sem8_dop;
    }
}
