package com.example.saurabh.e_campus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onStudent(View view)
    {
        Intent student = new Intent(MainActivity.this,student_main.class);
        startActivity(student);
    }

    public void onCompany(View view)
    {
        Intent company = new Intent(MainActivity.this,company_main.class);
        startActivity(company);
    }

    public void onTest(View view)
    {
        Intent company = new Intent(MainActivity.this,Main2Activity.class);
        startActivity(company);
    }
}
