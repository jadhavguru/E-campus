package com.example.saurabh.e_campus;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

import com.example.saurabh.e_campus.Model.student;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class student_reg_hsc extends AppCompatActivity {

    public static String fullnm,prn,gender,dob,email,contact,password,sscper,sscyop,sscboard;

    AutoCompleteTextView hscper,hscyop,hscboard;
    Button stuhsc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_reg_hsc);
        hscper = (AutoCompleteTextView)findViewById(R.id.hscper);
        hscyop = (AutoCompleteTextView)findViewById(R.id.hscyop);
        hscboard = (AutoCompleteTextView)findViewById(R.id.hscboard);
        stuhsc = (Button)findViewById(R.id.stuhsc);

        Intent i = getIntent();
        fullnm = i.getStringExtra("fullnm");
        prn = i.getStringExtra("prn");
        gender = i.getStringExtra("gender");
        dob = i.getStringExtra("dob");
        email = i.getStringExtra("email");
        contact = i.getStringExtra("contact");
        password = i.getStringExtra("password");
        sscper = i.getStringExtra("sscper");
        sscyop = i.getStringExtra("sscyop");
        sscboard = i.getStringExtra("sscboard");




    }


}
