package com.example.saurabh.e_campus;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.saurabh.e_campus.Model.BackgroundWorker;
import com.example.saurabh.e_campus.Model.student;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class student_reg_gen extends AppCompatActivity {


    AutoCompleteTextView fullnm,prn,dob,email,contact,pass,conpass;
    RadioGroup gen;
    RadioButton radioButton;
    TextView gender;
    Button stugen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_reg_gen);
        fullnm = (AutoCompleteTextView)findViewById(R.id.full_nm);
        prn = (AutoCompleteTextView)findViewById(R.id.prn);
        dob = (AutoCompleteTextView)findViewById(R.id.dob);
        email = (AutoCompleteTextView)findViewById(R.id.mail);
        contact = (AutoCompleteTextView)findViewById(R.id.contact);
        pass = (AutoCompleteTextView)findViewById(R.id.pass);
        conpass = (AutoCompleteTextView)findViewById(R.id.conpass);
        gen = (RadioGroup)findViewById(R.id.radgrp);
        gender = (TextView)findViewById(R.id.gender);
        stugen = (Button)findViewById(R.id.stugen);

        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = firebaseDatabase.getReference("student");

        stugen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog mdialog = new ProgressDialog(student_reg_gen.this);
                mdialog.setMessage("Please Wait...");
                mdialog.show();


                            String fullnmvalue = fullnm.getText().toString();
                            String prnvalue = prn.getText().toString();
                            String genvalue = gender.getText().toString();
                            String dobvalue = dob.getText().toString();
                            String emailvalue = email.getText().toString();
                            String contactvalue = contact.getText().toString();
                            String passvalue = pass.getText().toString();

                            String type="register";
                            BackgroundWorker backgroundWorker=new BackgroundWorker(student_reg_gen.this);
                            backgroundWorker.execute(type,prnvalue,fullnmvalue,genvalue,dobvalue,emailvalue,contactvalue,passvalue);



                            Intent studentregssc = new Intent(student_reg_gen.this,student_reg_ssc.class);
                            

                            startActivity(studentregssc);
                            finish();
                        }
                    });


        }

    }



