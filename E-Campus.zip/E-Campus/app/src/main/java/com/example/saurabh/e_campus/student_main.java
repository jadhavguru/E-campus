package com.example.saurabh.e_campus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class student_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_main);
    }

    public void onStudentreggen(View view)
    {
        Intent studentreggen = new Intent(student_main.this,student_reg_gen.class);
        startActivity(studentreggen);
    }
}
