package com.example.saurabh.e_campus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class company_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_main);
    }

    public void onCompanyReg(View view)
    {
        Intent companyreg = new Intent(company_main.this,company_reg.class);
        startActivity(companyreg);
    }
}
