package com.example.saurabh.e_campus;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

import com.example.saurabh.e_campus.Model.student;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class student_reg_ssc extends AppCompatActivity {

    public static String fullnm,prn,gender,dob,email,contact,password;
    AutoCompleteTextView sscper,sscyop,sscboard;
    Button stussc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_reg_ssc);
        sscper = (AutoCompleteTextView)findViewById(R.id.sscper);
        sscyop = (AutoCompleteTextView)findViewById(R.id.sscyop);
        sscboard = (AutoCompleteTextView)findViewById(R.id.sscboard);
        stussc = (Button)findViewById(R.id.stussc);

        Intent i = getIntent();
        fullnm = i.getStringExtra("fullnm");
        prn = i.getStringExtra("prn");
        gender = i.getStringExtra("gender");
        dob = i.getStringExtra("dob");
        email = i.getStringExtra("email");
        contact = i.getStringExtra("contact");
        password = i.getStringExtra("password");


    }

}
