package com.example.saurabh.e_campus;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

import com.example.saurabh.e_campus.Model.student;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class student_reg_grad extends AppCompatActivity {

    public static String fullnm,prn,gender,dob,email,contact,password,sscper,sscyop,sscboard,hscper,hscyop,hscboard;

    AutoCompleteTextView course,uni,cur_sem,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8,sem9,sem1dop,sem2dop,sem3dop,sem4dop,sem5dop,sem6dop,sem7dop,sem8dop;
    Button stugrad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_reg_grad);
        course = (AutoCompleteTextView)findViewById(R.id.course);
        uni = (AutoCompleteTextView)findViewById(R.id.uni);
        cur_sem = (AutoCompleteTextView)findViewById(R.id.current_sem);
        sem1 = (AutoCompleteTextView)findViewById(R.id.sem1);
        sem1dop = (AutoCompleteTextView)findViewById(R.id.sem1dop);
        sem2 = (AutoCompleteTextView)findViewById(R.id.sem2);
        sem2dop = (AutoCompleteTextView)findViewById(R.id.sem2dop);
        sem3 = (AutoCompleteTextView)findViewById(R.id.sem3);
        sem3dop = (AutoCompleteTextView)findViewById(R.id.sem3dop);
        sem4 = (AutoCompleteTextView)findViewById(R.id.sem4);
        sem4dop = (AutoCompleteTextView)findViewById(R.id.sem4dop);
        sem5 = (AutoCompleteTextView)findViewById(R.id.sem5);
        sem5dop = (AutoCompleteTextView)findViewById(R.id.sem5dop);
        sem6 = (AutoCompleteTextView)findViewById(R.id.sem6);
        sem6dop = (AutoCompleteTextView)findViewById(R.id.sem6dop);
        sem7 = (AutoCompleteTextView)findViewById(R.id.sem7);
        sem7dop = (AutoCompleteTextView)findViewById(R.id.sem7dop);
        sem8 = (AutoCompleteTextView)findViewById(R.id.sem8);
        sem8dop = (AutoCompleteTextView)findViewById(R.id.sem8dop);
        stugrad = (Button)findViewById(R.id.stugrad);

        Intent i = getIntent();
        fullnm = i.getStringExtra("fullnm");
        prn = i.getStringExtra("prn");
        gender = i.getStringExtra("gender");
        dob = i.getStringExtra("dob");
        email = i.getStringExtra("email");
        contact = i.getStringExtra("contact");
        password = i.getStringExtra("password");
        sscper = i.getStringExtra("sscper");
        sscyop = i.getStringExtra("sscyop");
        sscboard = i.getStringExtra("sscboard");
        hscper = i.getStringExtra("hscper");
        hscyop = i.getStringExtra("hscyop");
        hscboard = i.getStringExtra("hscboard");


        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = firebaseDatabase.getReference("student");



    }
}
